from flask import Flask, request, render_template

app = Flask(__name__)

allowed_credentials = [
    ("192.168.100.1", "pass111"),
    ("192.168.100.2", "pass222"),
    ("192.168.100.3", "pass333"),
    ("192.168.100.4", "pass444"),
    ("127.0.0.1", "mee"),
]


@app.route("/", methods=["GET"])
def home():
    ip = request.remote_addr
    password = request.args.get("password")
    print(password)

    if (ip, password) in allowed_credentials:
        return render_template("index.html")
    else:
        return render_template("error.html"), 403


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=3000)
